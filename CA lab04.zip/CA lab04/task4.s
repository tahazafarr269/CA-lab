main:
    addi x10, x0, 6
    jal  x1, fib
    addi x11, x10, 0
    addi x10, x0, 1
    ecall
    addi x10, x0, 10
    ecall

fib:
    addi x5, x0, 2
    blt  x10, x5, fib_ret
    addi sp, sp, -12
    sw   x1, 8(sp)
    sw   x10, 4(sp)
    sw   x18, 0(sp)
    addi x10, x10, -1
    jal  x1, fib
    addi x18, x10, 0
    lw   x10, 4(sp)
    addi x10, x10, -2
    jal  x1, fib
    add  x10, x10, x18
    lw   x18, 0(sp)
    lw   x1, 8(sp)
    addi sp, sp, 12
fib_ret:
    jalr x0, 0(x1)