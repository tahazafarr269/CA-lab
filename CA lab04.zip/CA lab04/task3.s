.data
arr: .word 5, -3, 12, 0, 7, 25, -8, 1

.text
main:
    la   x10, arr
    addi x11, x0, 8
    jal  x1, bubble
    addi x10, x0, 10
    ecall

bubble:
    beq  x10, x0, ret
    beq  x11, x0, ret
    addi x5, x0, 0
outer:
    bgeu x5, x11, ret
    addi x6, x5, 0
inner:
    bgeu x6, x11, next_i
    slli x7, x5, 2
    add  x7, x10, x7
    slli x28, x6, 2
    add  x28, x10, x28
    lw   x29, 0(x7)
    lw   x30, 0(x28)
    bge  x29, x30, next_j
    sw   x30, 0(x7)
    sw   x29, 0(x28)
next_j:
    addi x6, x6, 1
    jal  x0, inner
next_i:
    addi x5, x5, 1
    jal  x0, outer
ret:
    jalr x0, 0(x1)